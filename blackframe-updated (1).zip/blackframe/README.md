# BLACK FRAME
Full-stack site: Node/Express + SQLite, vanilla cinematic front end, mobile-first admin at /admin.
## Run
npm install && cp .env.example .env (fill in) && export $(cat .env|xargs) && npm start
First start seeds the admin from ADMIN_EMAIL / ADMIN_PASSWORD (12+ chars). Remove the password from .env afterwards, and enable 2FA in Admin > Security.
Deploy behind HTTPS (Render, Railway, Fly, VPS). Mobile-only workflow: push to GitHub, deploy on Render.
## Needs YOUR credentials / work
- Razorpay: key id/secret + webhook (event payment.captured) -> https://YOURDOMAIN/api/pay/webhook with RAZORPAY_WEBHOOK_SECRET. Payments stay off without keys.
- Rewarded ads: wire your ad network SDK in index.html `watch()`. Configure the network's server-side verification callback to GET /api/ads/ssv?nonce=..&revenue=..&sig=HMAC_SHA256(AD_SSV_SECRET, nonce|revenue). Some networks (AdMob) use their own signature scheme: adapt that one function. Revenue shown is only what the callback reports; confirm with your ad network's dashboard.
- Uploaded builds are private and need manual approval. Run ClamAV (or similar) before approving.
## Honest limits
- Database is SQLite (single file, back it up). Swapping to PostgreSQL means replacing better-sqlite3 calls.
- Sessions use the in-memory store: use a persistent store for multi-instance deployments.
- Frontend is vanilla JS, not React/Framer Motion, to keep it light on phones. Image upload for screenshots is via URL; builds use private storage.
- Not security-audited: review before taking real money.

## Phase 2 additions (BLACK FRAME STUDIO / NIGHT SHIFT)
- Studio = BLACK FRAME STUDIO (nav, loader, footer). Game = NIGHT SHIFT (hero, downloads, titles). If you saved a title earlier, re-save it in Admin > Settings.
- Admin > Sections: show/hide, retitle, add description, reorder.
- Admin > Appearance: colors, radius, spacing, heading font, effects on/off, live preview, reset.
- Admin > Ads: add/edit/delete/move AdSense slots (placement, unit ID, size, max width, margin, padding, desktop/mobile, colors). Set ADSENSE_CLIENT=ca-pub-... in .env. A slot renders publicly only if enabled + unit ID + ADSENSE_CLIENT are set. Preview boxes are layout only.
- Fixed: CSP blocked Razorpay checkout; now allowed. Button labels editable.
## Not built yet
Player accounts (the ZIP had none), Razorpay already present but untested, ad analytics from provider APIs, image/video upload, roles, migrations, backups guide.
## Untested
No dependencies could be installed in my environment, so the server was never started. Only syntax checks and the validation helpers were run. Run `npm install && npm start` and test before use.
## MediaFire link mode
Admin > Game: paste a https://www.mediafire.com/... link instead of uploading. Nothing is stored on your server. The link is not in the public page; it is returned only with a valid one-time grant (after a verified ad, payment, or free), which expires in 10 minutes. Once shown, a player can copy or share it: that cannot be prevented. Automatic upload to MediaFire is not built (needs MediaFire API credentials and I could not verify it).
